from importlib import resources as importlib_resources
from dearpygui import dearpygui as dpg
from softinka.dpg_context_manager import dpg_context_manager


resources = importlib_resources.files("softinka").joinpath("resources")

def main() -> None:
    with dpg_context_manager():
        dpg.create_viewport()
        dpg.set_viewport_large_icon(resources.joinpath("icons/icon.png"))
        dpg.configure_app(docking=True, docking_space=True, load_init_file=resources.joinpath("dpg.ini"), auto_save_init_file=True)
        dpg.setup_dearpygui()
        with dpg.font_registry():
            with dpg.font(resources.joinpath("fonts/Roboto-Regular.ttf"), 22) as default_font:
                dpg.add_font_range(0x0100, 0x100000)
                dpg.bind_font(default_font)

        dpg.set_viewport_title("Softinka by Aeek True")
        with dpg.window(label="Main Window") as pw:
            dpg.add_text(f"me: {__file__}")

        # dpg.set_primary_window(pw, True)
        dpg.show_viewport()

        while dpg.is_dearpygui_running():
            dpg.render_dearpygui_frame()
